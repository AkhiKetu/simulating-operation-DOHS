package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class AssignPatrolRoutes3Controller {

    @FXML
    private ComboBox<?> guardNameComboBox;

    @FXML
    private TableColumn<?, ?> guardNameTableColumn;

    @FXML
    private TableColumn<?, ?> patrolAreaTableColumn;

    @FXML
    private TextField patrolAreaTextField;

    @FXML
    private TableColumn<?, ?> shiftTimeTableColumn;

    @FXML
    private TextField shiftTimeTextField;

    @FXML
    private TableView<?> tableViewShow;

    @FXML
    void saveAssignmentOnButtonMouseClick(ActionEvent event) {

    }

}
