package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class ManageParkingViolationsController {

    @FXML
    private TableColumn<?, ?> LocationTypeTableColumn;

    @FXML
    private Label locationTextField;

    @FXML
    private TableColumn<?, ?> vehicleNumberTableColumn;

    @FXML
    private TextField vehicleNumberTextField;

    @FXML
    private TableView<?> violationTableData;

    @FXML
    private TableColumn<?, ?> violationTypeTableColumn;

    @FXML
    private TextField violationTypeTextField;

    @FXML
    void saveButtonOnMouseClick(ActionEvent event) {

    }

    @FXML
    void viewHistoryOnMouseClick(ActionEvent event) {

    }

}
