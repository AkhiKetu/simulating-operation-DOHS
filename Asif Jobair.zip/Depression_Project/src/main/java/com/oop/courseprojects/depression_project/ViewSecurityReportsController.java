package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ViewSecurityReportsController {

    @FXML
    private TableColumn<?, ?> fromDataTableColumn;

    @FXML
    private DatePicker fromDateDatePicker;

    @FXML
    private ComboBox<?> reportTypeComboBox;

    @FXML
    private TableColumn<?, ?> reportTypeTablecolumn;

    @FXML
    private TableView<?> tableViewData;

    @FXML
    private DatePicker toDateDatePicker;

    @FXML
    private TableColumn<?, ?> toDatetableColumn;

    @FXML
    void exportButtonOnMouseClick(ActionEvent event) {

    }

    @FXML
    void filterButtonOnMouseClick(ActionEvent event) {

    }

}

