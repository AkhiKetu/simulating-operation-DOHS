package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class ApproveRefundRequest55Controller {

    @FXML
    private AnchorPane requestDeatailsTextField;

    @FXML
    private TextField requestDetails;

    @FXML
    private TextField statusDetails;

    @FXML
    void RejectButtonOnMouse(ActionEvent event) {

    }

    @FXML
    void approveButtonOnMouse(ActionEvent event) {

    }

    @FXML
    void loadRequestOnButtonOnMouse(ActionEvent event) {

    }

}
