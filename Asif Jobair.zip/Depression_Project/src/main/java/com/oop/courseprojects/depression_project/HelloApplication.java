package com.oop.courseprojects.depression_project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        //FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));

        SceneSwitcher.setMainstage(stage);
        SceneSwitcher.setGlobal_class_handle(getClass());
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AssignPatrolRoutes3.fxml"));
        //FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MonitorfinancialTransactions66.fxml"));
        //THIS part is necessary for SceneSwitcher to work, it needs a reference to getClass() so it can open fxml files
        /* THIS part */
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}