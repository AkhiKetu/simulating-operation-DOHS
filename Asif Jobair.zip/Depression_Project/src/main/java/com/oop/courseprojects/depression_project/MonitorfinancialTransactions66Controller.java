package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class MonitorfinancialTransactions66Controller {

    @FXML
    private TableView<?> FianancialTransactionTable;

    @FXML
    private DatePicker fromDatePicker;

    @FXML
    private TableColumn<?, ?> fromTableColumn;

    @FXML
    private TableColumn<?, ?> searchTableColumn;

    @FXML
    private TextField searchTextField;

    @FXML
    private DatePicker toDatePicker;

    @FXML
    private TableColumn<?, ?> totableColumn;

    @FXML
    void addButtonOnMouseClick(ActionEvent event) {

    }

}

