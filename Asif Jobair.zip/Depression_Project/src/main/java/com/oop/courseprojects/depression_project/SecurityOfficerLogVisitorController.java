package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;

public class SecurityOfficerLogVisitorController {

    @FXML
    private DatePicker entryTimeDatePicker;

    @FXML
    private DatePicker entryTimeDatePicker1;

    @FXML
    private TableColumn<?, ?> entryTimeTimeColumn;

    @FXML
    private TableColumn<?, ?> exitTimeTableColumn;

    @FXML
    private TextField purposeTextField;

    @FXML
    private TableColumn<?, ?> residentNameTableColumn;

    @FXML
    private TextField residentNameTextField;

    @FXML
    private TableColumn<?, ?> visitorNameTableColumn;

    @FXML
    private TextField visitorNameTextField;

    @FXML
    void saveEntryButtonOnMouseClick(ActionEvent event) {

    }

    @FXML
    void saveExitButtonOnMouseClick(ActionEvent event) {

    }

    @FXML
    void tableViewData(ActionEvent event) {

    }

}
