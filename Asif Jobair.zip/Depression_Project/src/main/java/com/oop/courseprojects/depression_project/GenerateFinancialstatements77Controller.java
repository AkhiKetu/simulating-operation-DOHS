package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;

public class GenerateFinancialstatements77Controller {

    @FXML
    private TextArea stamentPreviewAreaTextArea;

    @FXML
    private DatePicker statementEndDatePicker;

    @FXML
    private DatePicker statementStartDatePicker;

    @FXML
    void exportStatementButtonOnMouseClick(ActionEvent event) {

    }

    @FXML
    void genarateStatementButtonOnClick(ActionEvent event) {

    }

}

