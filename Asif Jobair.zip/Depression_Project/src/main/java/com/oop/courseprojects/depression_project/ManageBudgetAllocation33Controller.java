package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class ManageBudgetAllocation33Controller {

    @FXML
    private TableColumn<?, ?> allocatedTableColumn;

    @FXML
    private TextField allocatedamountField;

    @FXML
    private TextField budgetCategoryFieldTextField;

    @FXML
    private TableView<?> budgettableView;

    @FXML
    private TableColumn<?, ?> categorytablecolumn;

    @FXML
    void updateButtonOnMouseClick(ActionEvent event) {

    }

}
