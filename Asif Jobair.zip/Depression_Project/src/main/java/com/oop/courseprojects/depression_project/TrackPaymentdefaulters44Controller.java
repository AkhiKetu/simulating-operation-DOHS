package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class TrackPaymentdefaulters44Controller {

    @FXML
    private TableView<?> DefaultersTable;

    @FXML
    private TableColumn<?, ?> StatusLevelTableColumn;

    @FXML
    private TableColumn<?, ?> searchFieldTableColumn;

    @FXML
    private TextField searchFieldTextField;

    @FXML
    private TextField statusLevelTextField;

    @FXML
    void loadDefaulters(ActionEvent event) {

    }

    @FXML
    void sendRemindersButtonOnMouseClick(ActionEvent event) {

    }

}

