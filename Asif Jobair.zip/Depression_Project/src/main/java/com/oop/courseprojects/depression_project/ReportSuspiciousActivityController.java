package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ReportSuspiciousActivityController {

    @FXML
    private Label confirmationMessageLabel;

    @FXML
    private TextArea descriptionTextArea;

    @FXML
    private TextArea extraInfoTextArea;

    @FXML
    private TextField locationTextField;

    @FXML
    private TextField timeTextField;

    @FXML
    void backButtonOnMouseClick(ActionEvent event) {
        SceneSwitcher.switchToScene(SceneSwitcher.getStageFromEvent(event), "IssueSecurityAlerts8.fxml");



    }

    @FXML
    void submitButtonOnMouseClick(ActionEvent event) {


    }

}
