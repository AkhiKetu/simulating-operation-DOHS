package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class ApproveVendorPayments88Controller {

    @FXML
    private TextArea invoiceDetailAreaTextArea;

    @FXML
    void approveButtonOnMouse(ActionEvent event) {

    }

    @FXML
    void loadInvoiceButtonOnMouse(ActionEvent event) {

    }

    @FXML
    void rejectButtonOnMouseClick(ActionEvent event) {

    }

}
