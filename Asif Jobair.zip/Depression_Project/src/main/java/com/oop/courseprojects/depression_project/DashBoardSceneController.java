package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class DashBoardSceneController {

    @FXML
    void visitorLogButtonOnMouseClick(ActionEvent event) {
        SceneSwitcher.switchToScene(SceneSwitcher.getStageFromEvent(event), "SecurityOfficerLogVisitor.fxml");
    }



}
