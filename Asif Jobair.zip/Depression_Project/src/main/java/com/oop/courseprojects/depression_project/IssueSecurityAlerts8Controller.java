package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class IssueSecurityAlerts8Controller {

    @FXML
    private ComboBox<?> alertTypeComboBox;

    @FXML
    private Label alertsentLabel;

    @FXML
    private TextArea decriptionTextArea;

    @FXML
    private TextField locationTextField;

    @FXML
    void submitAlertOnButtonMouseClick(ActionEvent event) {

    }

}
