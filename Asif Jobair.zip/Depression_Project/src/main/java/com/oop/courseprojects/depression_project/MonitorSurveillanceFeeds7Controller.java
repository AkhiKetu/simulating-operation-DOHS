package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;

public class MonitorSurveillanceFeeds7Controller {

    @FXML
    private TextArea addObservationNotesTextArea;

    @FXML
    private ImageView imageHereImageView;

    @FXML
    private ComboBox<?> locationCombobox;

    @FXML
    void takeSnapshotButtonOnmouseClick(ActionEvent event) {
        SceneSwitcher.switchToScene(SceneSwitcher.getStageFromEvent(event), "IssueSecurityAlerts8.fxml");
    }

    @FXML
    void viewHistoryonMouseclick(ActionEvent event) {

    }

}
