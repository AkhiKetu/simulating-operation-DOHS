package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;

public class GenerateMonthlyReport22Controller {

    @FXML
    private DatePicker endDatePickerTextField;

    @FXML
    private TextArea reportPerviewareaTextArea;

    @FXML
    private ComboBox<?> reprtTypeComboBox;

    @FXML
    private DatePicker startdatePickerTextField;

    @FXML
    void exportButtonClick(ActionEvent event) {


    }

    @FXML
    void genarateButtonOnMouseClick(ActionEvent event) {

    }

}
