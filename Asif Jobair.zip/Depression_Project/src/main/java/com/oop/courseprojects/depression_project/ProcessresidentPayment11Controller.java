package com.oop.courseprojects.depression_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class ProcessresidentPayment11Controller {

    @FXML
    private TableView<?> PaymentTableData;

    @FXML
    private ComboBox<?> paymentTypeBoxComboBox;

    @FXML
    private TableColumn<?, ?> paymenttypeboxTextcolumn;

    @FXML
    private TableColumn<?, ?> residentIdFieldTablecolumn;

    @FXML
    private TextField residentIdfieldTextField;

    @FXML
    void markAsPaidButtonOnClick(ActionEvent event) {

    }

}

