module com.oop.courseprojects.depression_project {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.oop.courseprojects.depression_project to javafx.fxml;
    exports com.oop.courseprojects.depression_project;
}